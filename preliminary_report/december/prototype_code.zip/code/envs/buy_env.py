# import gym
# import numpy as np
# from gym import spaces


# class BuyEnv(gym.Env):

#     metadata = {"render.modes": ["human"]}

#     def __init__(self, state_window_df, price_series, horizon=5, transaction_cost=0.001):
#         super().__init__()

#         self.states = state_window_df.values.astype(np.float32)
#         self.prices = price_series.values.astype(np.float32)

#         self.horizon = horizon
#         self.cost = transaction_cost
#         self.idx = 0

#         self.action_space = spaces.Discrete(2)
#         self.observation_space = spaces.Box(
#             low=-np.inf, high=np.inf, shape=(self.states.shape[1],), dtype=np.float32
#         )

#     def reset(self):
#         self.idx = 0
#         return self.states[self.idx]

#     def step(self, action):
#         done = False
#         reward = 0.0

#         if action == 1:  # BUY
#             entry = self.prices[self.idx]
#             exit_idx = min(self.idx + self.horizon, len(self.prices) - 1)
#             exit_price = self.prices[exit_idx]
#             reward = (exit_price - entry) / entry - self.cost
#             #  TODO: Change for PROD release to keep on training
#             # done = False
#             done = True

#         self.idx += 1
#         if self.idx >= len(self.states) - 1:
#             done = True

#         next_state = self.states[self.idx]

#         return next_state, float(reward), done, {"t": self.idx, "price": float(self.prices[self.idx])}

#     def render(self):
#         print(f"t={self.idx}, price={self.prices[self.idx]}")

import numpy as np
import gym
from gym import spaces


class BuyEnv(gym.Env):
    """
    Production BUY environment.

    Actions:
        0 = HOLD
        1 = BUY

    Behaviour:
    - When flat and agent selects BUY (1):
        -> open a long position at current price.
    - When already long and agent selects BUY:
        -> treated as HOLD (no scaling in/out for now).
    - Position is automatically closed when:
        -> holding_steps >= horizon, or
        -> we reach the end of the dataset.

    Reward:
    - 0 on normal HOLD steps (by default).
    - On CLOSE:
        reward = gross_return - transaction_cost
                 - lambda_dd * |max_drawdown|
                 - lambda_vol * volatility
                 - lambda_tf * num_trades

    Episode:
    - Starts at index 0.
    - Ends when we reach the last time step.
    - Multiple trades are allowed within one episode.
    """

    metadata = {"render.modes": ["human"]}

    def __init__(
        self,
        state_window_df,
        price_series,
        horizon: int = 5,
        transaction_cost: float = 0.001,
        lambda_dd: float = 0.5,     # drawdown penalty scale
        lambda_vol: float = 0.1,    # volatility penalty scale
        lambda_tf: float = 0.001,   # trade frequency penalty scale
        hold_penalty_flat: float = 0.0,   # optional small penalty when flat
        hold_penalty_long: float = 0.0,   # optional penalty per step in position
        max_episode_steps: int | None = None,
    ):
        super().__init__()

        self.state_df = state_window_df
        self.price_series = price_series
        self.horizon = horizon
        self.transaction_cost = transaction_cost
        self.lambda_dd = lambda_dd
        self.lambda_vol = lambda_vol
        self.lambda_tf = lambda_tf
        self.hold_penalty_flat = hold_penalty_flat
        self.hold_penalty_long = hold_penalty_long

        self.num_states = state_window_df.shape[0]
        self.num_features = state_window_df.shape[1]

        # Gym spaces
        self.action_space = spaces.Discrete(2)  # 0 = HOLD, 1 = BUY
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(self.num_features,),
            dtype=np.float32,
        )

        # Internal state
        self.idx: int = 0
        self.position: int = 0  # 0 = flat, 1 = long
        self.entry_price: float | None = None
        self.entry_idx: int | None = None
        self.num_trades: int = 0
        self.episode_steps: int = 0
        self.max_episode_steps = max_episode_steps

    # ------------------------------------------------------------------ #
    # Core API
    # ------------------------------------------------------------------ #

    def reset(self):
        self.idx = 0
        self.position = 0
        self.entry_price = None
        self.entry_idx = None
        self.num_trades = 0
        self.episode_steps = 0

        return self._get_state()

    def _get_state(self) -> np.ndarray:
        return self.state_df.iloc[self.idx].values.astype(np.float32)

    def step(self, action: int):
        """
        Step the environment by one time step.

        1) Apply action (HOLD or BUY).
        2) If in a long position, check if we must close (horizon / end).
        3) Compute reward (non-zero only when closing by default).
        4) Move to next time index.
        """
        assert self.action_space.contains(action), f"Invalid action {action}"

        done = False
        info = {}
        reward = 0.0

        current_price = self.price_series.iloc[self.idx]

        # ------------------------------------
        # 1) Apply Action
        # ------------------------------------
        if self.position == 0:
            # We are FLAT
            if action == 1:
                # Open new long
                self.position = 1
                self.entry_price = current_price
                self.entry_idx = self.idx
                self.num_trades += 1

                # Optionally apply transaction cost immediately:
                # reward -= self.transaction_cost
            else:
                # HOLD while flat
                reward -= self.hold_penalty_flat

        else:
            # We are LONG
            # Treat BUY as HOLD for now (no leverage / scaling)
            reward -= self.hold_penalty_long

        # ------------------------------------
        # 2) Check Close Conditions
        # ------------------------------------
        close_position = False

        if self.position == 1:
            holding_steps = self.idx - (self.entry_idx or self.idx)
            # Close if horizon reached OR we are at the last price index
            if holding_steps >= self.horizon or self.idx >= self.num_states - 1:
                close_position = True

        if close_position and self.position == 1 and self.entry_idx is not None:
            exit_price = current_price

            # Realised return
            gross_return = (exit_price - self.entry_price) / self.entry_price

            # Price window for risk metrics
            price_window = self.price_series.iloc[self.entry_idx : self.idx + 1]

            if len(price_window) > 1:
                peak = price_window.max()
                trough = price_window.min()
                max_drawdown = (trough - peak) / peak  # <= 0

                # Volatility as std dev of log-returns
                returns = price_window.pct_change().dropna()
                volatility = returns.std() if len(returns) > 0 else 0.0
            else:
                max_drawdown = 0.0
                volatility = 0.0

            drawdown_penalty = self.lambda_dd * abs(max_drawdown)
            volatility_penalty = self.lambda_vol * volatility
            frequency_penalty = self.lambda_tf * self.num_trades

            trade_reward = (
                gross_return
                - self.transaction_cost
                - drawdown_penalty
                - volatility_penalty
                - frequency_penalty
            )

            reward += trade_reward

            # Reset position
            self.position = 0
            self.entry_price = None
            self.entry_idx = None

            # Optionally include trade details in info (for logging)
            info["trade_reward"] = trade_reward
            info["gross_return"] = gross_return
            info["max_drawdown"] = max_drawdown
            info["volatility"] = volatility

        # ------------------------------------
        # 3) Advance Time
        # ------------------------------------
        self.episode_steps += 1

        # Move to next index
        self.idx += 1
        if self.idx >= self.num_states - 1:
            done = True

        if self.max_episode_steps is not None and self.episode_steps >= self.max_episode_steps:
            done = True

        # If done, you can choose to force-close any open position
        if done and self.position == 1 and self.entry_idx is not None:
            # Force close at final price
            final_price = self.price_series.iloc[min(self.idx, self.num_states - 1)]
            gross_return = (final_price - self.entry_price) / self.entry_price

            price_window = self.price_series.iloc[self.entry_idx : min(self.idx, self.num_states)]
            if len(price_window) > 1:
                peak = price_window.max()
                trough = price_window.min()
                max_drawdown = (trough - peak) / peak
                returns = price_window.pct_change().dropna()
                volatility = returns.std() if len(returns) > 0 else 0.0
            else:
                max_drawdown = 0.0
                volatility = 0.0

            drawdown_penalty = self.lambda_dd * abs(max_drawdown)
            volatility_penalty = self.lambda_vol * volatility
            frequency_penalty = self.lambda_tf * self.num_trades

            closing_reward = (
                gross_return
                - self.transaction_cost
                - drawdown_penalty
                - volatility_penalty
                - frequency_penalty
            )
            reward += closing_reward

            # Clear position
            self.position = 0
            self.entry_price = None
            self.entry_idx = None

            info["forced_close_reward"] = closing_reward
            info["forced_close_gross_return"] = gross_return

        # ------------------------------------
        # 4) Next State
        # ------------------------------------
        if not done:
            next_state = self._get_state()
        else:
            # Zero-state at the end (safe default)
            next_state = np.zeros(self.num_features, dtype=np.float32)

        return next_state, float(reward), done, info

    def render(self, mode="human"):
        # Optional: implement for visualization
        pass
